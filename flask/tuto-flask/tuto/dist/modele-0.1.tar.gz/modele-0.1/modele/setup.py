from setuptools import setup

setup(
    name="modele",
    version="0.1",
    description="test",
    author="baba",
    packages=["modele"],
)