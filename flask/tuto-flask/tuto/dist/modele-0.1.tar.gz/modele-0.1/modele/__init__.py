import sys
print(sys.path)
#
#__all__=["modele"]
#from . import modele